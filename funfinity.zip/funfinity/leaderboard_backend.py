import firebase_admin
from firebase_admin import credentials, firestore

# Initialize Firebase
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Register new player (first login)
def register_player(player_name):
    db.collection("players").document(player_name).set({
        "name": player_name,
        "score": 0
    })

# Update score when player plays
def update_score(player_name, points):
    player_ref = db.collection("players").document(player_name)
    player_ref.update({
        "score": firestore.Increment(points)
    })

# Get current leaderboard
def get_leaderboard():
    players = db.collection("players").order_by("score", direction=firestore.Query.DESCENDING).stream()
    print("\n=== Leaderboard ===")
    for i, player in enumerate(players, 1):
        data = player.to_dict()
        print(f"{i}. {data['name']} - {data['score']}")

# Demo run
if __name__ == "__main__":
    register_player("Aarav")
    register_player("Bhumika")
    update_score("Aarav", 50)
    update_score("Bhumika", 80)
    get_leaderboard()
