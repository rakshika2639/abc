import { initializeApp } from "https://www.gstatic.com/firebasejs/10.5.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.5.0/firebase-firestore.js";

console.log("Script loaded ✅");

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCbYG3ePH3NU-CV4SVVGA5h5XUiTwKbV7g",
  authDomain: "funfinity-leaderboard.firebaseapp.com",
  projectId: "funfinity-leaderboard",
  storageBucket: "funfinity-leaderboard.firebasestorage.app",
  messagingSenderId: "70581728570",
  appId: "1:70581728570:web:a5ddf4f9319322d52c4c03"
};

  // Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Load leaderboard
async function loadLeaderboard() {
  try {
    console.log("Fetching leaderboard...");
    const querySnapshot = await getDocs(collection(db, "players"));
    let players = [];
    querySnapshot.forEach((doc) => {
      console.log("Doc:", doc.id, "=>", doc.data()); // 👈 see if data is returned
      players.push(doc.data());
    });

    if (players.length === 0) {
      console.warn("No players found in Firestore!");
    }

    players.sort((a, b) => b.score - a.score);

    let tableBody = document.getElementById("leaderboard-body");
    tableBody.innerHTML = "";
    players.forEach((player, index) => {
      tableBody.innerHTML += `
        <tr>
          <td>${index + 1}</td>
          <td>${player.name}</td>
          <td>${player.score}</td>
        </tr>`;
    });
  } catch (err) {
    console.error("Error loading leaderboard:", err);
  }
}

loadLeaderboard(); // 👈 this runs immediately when page loads
setInterval(loadLeaderboard, 3000); // 👈 then repeats every 3 sec

